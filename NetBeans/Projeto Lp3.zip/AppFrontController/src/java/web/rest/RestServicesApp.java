package web.rest;

import javax.ws.rs.ApplicationPath;

@ApplicationPath("LP3Rest")
public class RestServicesApp extends javax.ws.rs.core.Application {

}
